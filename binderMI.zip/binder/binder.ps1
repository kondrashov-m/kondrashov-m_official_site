﻿$ErrorActionPreference = 'Stop'

Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @'
using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public static class Binder {
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
    [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr h, uint a, uint b);
    [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
    [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);

    [StructLayout(LayoutKind.Sequential)]
    public struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }

    const uint MOD_CONTROL = 0x0002, MOD_NOREPEAT = 0x4000, WM_HOTKEY = 0x0312;
    const int VK_CONTROL = 0x11, VK_V = 0x56, VK_F1 = 0x70;

    public static void Run(string dir) {
        for (int i = 1; i <= 12; i++) {
            bool ok = RegisterHotKey(IntPtr.Zero, i, MOD_CONTROL | MOD_NOREPEAT, (uint)(VK_F1 + i - 1));
            Console.WriteLine(ok ? "  Ctrl+F" + i + "  ->  binds\\F" + i + ".txt"
                                 : "  Ctrl+F" + i + "  занят другой программой");
        }
        MSG m;
        while (GetMessage(out m, IntPtr.Zero, 0, 0) > 0) {
            if (m.message == WM_HOTKEY) Fire(dir, (int)m.wParam);
        }
    }

    static void Fire(string dir, int n) {
        string file = Path.Combine(dir, "F" + n + ".txt");
        if (!File.Exists(file)) return;
        string text = File.ReadAllText(file, Encoding.UTF8).TrimEnd('\r', '\n');
        if (text.Length == 0) return;

        // ждём, пока отпустят F-клавишу (максимум 1 сек)
        for (int k = 0; k < 100 && (GetAsyncKeyState(VK_F1 + n - 1) & 0x8000) != 0; k++) Thread.Sleep(10);

        try { Clipboard.SetText(text); } catch { return; }
        keybd_event(VK_CONTROL, 0, 0, UIntPtr.Zero);
        keybd_event(VK_V, 0, 0, UIntPtr.Zero);
        keybd_event(VK_V, 0, 2, UIntPtr.Zero);
        keybd_event(VK_CONTROL, 0, 2, UIntPtr.Zero);
        Console.WriteLine("  [" + DateTime.Now.ToString("HH:mm:ss") + "] F" + n + " вставлен");
    }
}
'@

$dir = Join-Path $PSScriptRoot 'binds'
if (-not (Test-Path $dir)) { New-Item -ItemType Directory $dir | Out-Null }

Write-Host ""
Write-Host "  ===================================" -ForegroundColor Cyan
Write-Host "    БИНДЕР   |   разработчик: kondrashov-m" -ForegroundColor Cyan
Write-Host "  ===================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  БИНДЕР запущен. Тексты лежат в папке binds" -ForegroundColor Green
Write-Host "  Чтобы выключить - просто закрой это окно."
Write-Host ""
[Binder]::Run($dir)
